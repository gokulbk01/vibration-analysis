# vibration_analysis/preprocessor.py
import pandas as pd
import numpy as np
from typing import Dict, Optional, Tuple
from datetime import datetime


class VibrationPreprocessor:
    """
    A class for preprocessing vibration data with moving average and anomaly detection.
    
    This preprocessor handles:
    - Data filtering based on minimum TVE threshold
    - Outlier removal using standard deviation
    - Moving average calculation
    - Reference point extraction
    - Deviation calculation for anomaly detection
    """
    
    def __init__(self, 
                 moving_average_window: int = 30,
                 min_tve: float = 0.065,
                 outlier_std_threshold: float = 8.0):
        """
        Initialize the VibrationPreprocessor.
        
        Parameters:
        -----------
        moving_average_window : int, default=30
            Window size for moving average calculation
        min_tve : float, default=0.065
            Minimum threshold vibration energy to filter data
        outlier_std_threshold : float, default=8.0
            Standard deviation multiplier for outlier detection
        """
        self.moving_average_window = moving_average_window
        self.min_tve = min_tve
        self.outlier_std_threshold = outlier_std_threshold
        
    def load_and_validate_data(self, 
                               data: pd.DataFrame,
                               datetime_col: str = 'Date/Time',
                               broadband_col: str = 'Broadband') -> pd.DataFrame:
        """
        Load and validate vibration data.
        
        Parameters:
        -----------
        data : pd.DataFrame
            Input dataframe containing vibration data
        datetime_col : str, default='Date/Time'
            Name of the datetime column
        broadband_col : str, default='Broadband'
            Name of the broadband column
            
        Returns:
        --------
        pd.DataFrame
            Validated and cleaned dataframe
        """
        # Create a copy to avoid modifying original
        df = data.copy()
        
        # Validate required columns
        if datetime_col not in df.columns or broadband_col not in df.columns:
            raise ValueError(f"Required columns '{datetime_col}' and/or '{broadband_col}' not found")
        
        # Remove any rows with string values in broadband
        df = df[df[broadband_col] != 'inches/second']
        
        # Convert datetime
        df[datetime_col] = pd.to_datetime(df[datetime_col])
        
        # Convert broadband to numeric
        df[broadband_col] = pd.to_numeric(df[broadband_col], errors='coerce')
        
        # Remove rows with NaN values
        df = df.dropna(subset=[datetime_col, broadband_col])
        
        return df
    
    def filter_by_threshold(self, 
                           data: pd.DataFrame,
                           broadband_col: str = 'Broadband') -> pd.DataFrame:
        """
        Filter data based on minimum TVE threshold.
        
        Parameters:
        -----------
        data : pd.DataFrame
            Input dataframe
        broadband_col : str, default='Broadband'
            Name of the broadband column
            
        Returns:
        --------
        pd.DataFrame
            Filtered dataframe
        """
        mask = data[broadband_col] >= self.min_tve
        return data[mask].copy()
    
    def remove_outliers(self, 
                       data: pd.DataFrame,
                       broadband_col: str = 'Broadband') -> Tuple[pd.DataFrame, pd.DataFrame, float]:
        """
        Remove isolated outliers using standard deviation method.
        Only removes isolated points, not consecutive sequences.
        
        Parameters:
        -----------
        data : pd.DataFrame
            Input dataframe
        broadband_col : str, default='Broadband'
            Name of the broadband column
            
        Returns:
        --------
        Tuple[pd.DataFrame, pd.DataFrame, float]
            (cleaned_data, removed_data, threshold_value)
        """
        df = data.copy()
        
        # Calculate statistics
        std_dev = df[broadband_col].std()
        mean_val = df[broadband_col].mean()
        threshold = mean_val + self.outlier_std_threshold * std_dev
        
        # Identify high values
        is_high_value = df[broadband_col] > threshold
        
        # Find sequences of consecutive high values
        is_consecutive = pd.Series(False, index=df.index)
        
        # Check for consecutive points
        for i in range(len(is_high_value) - 1):
            if is_high_value.iloc[i] and is_high_value.iloc[i+1]:
                is_consecutive.iloc[i] = True
                is_consecutive.iloc[i+1] = True
        
        # Only remove isolated outliers
        to_remove = is_high_value & (~is_consecutive)
        
        removed_data = df[to_remove]
        cleaned_data = df[~to_remove]
        
        return cleaned_data, removed_data, threshold
    
    def calculate_moving_average(self, 
                                 data: pd.DataFrame,
                                 broadband_col: str = 'Broadband') -> pd.DataFrame:
        """
        Calculate moving average of broadband values.
        
        Parameters:
        -----------
        data : pd.DataFrame
            Input dataframe
        broadband_col : str, default='Broadband'
            Name of the broadband column
            
        Returns:
        --------
        pd.DataFrame
            Dataframe with added 'Moving_Average' column
        """
        df = data.copy()
        df['Moving_Average'] = df[broadband_col].rolling(
            window=self.moving_average_window, 
            min_periods=1
        ).mean()
        return df
    
    def get_reference_points(self, 
                            data: pd.DataFrame,
                            datetime_col: str = 'Date/Time') -> Dict:
        """
        Extract three reference points (early, middle, late) from moving average values.
        Ensures points are from different months when possible.
        
        Parameters:
        -----------
        data : pd.DataFrame
            Input dataframe with 'Moving_Average' column
        datetime_col : str, default='Date/Time'
            Name of the datetime column
            
        Returns:
        --------
        Dict
            Dictionary containing reference point information
        """
        reference_points = {}
        
        if len(data) <= self.moving_average_window:
            return reference_points
        
        # Get available data points after moving average stabilizes
        available_data = data.iloc[self.moving_average_window-1:].copy()
        
        if len(available_data) == 0:
            return reference_points
        
        # Add month column
        available_data['Month'] = available_data[datetime_col].dt.to_period('M')
        
        # Calculate target indices
        total_available = len(available_data)
        segment_size = max(1, total_available // 3)
        
        target_indices = [
            min(29, segment_size - 1),
            min(segment_size + 29, total_available // 2),
            min(2 * segment_size + 29, total_available - 1)
        ]
        
        point_names = ['Early_Period', 'Middle_Period', 'Late_Period']
        selected_points = []
        used_months = set()
        
        for target_idx, point_name in zip(target_indices, point_names):
            if target_idx < len(available_data):
                candidate_point = available_data.iloc[target_idx]
                candidate_month = candidate_point['Month']
                
                if candidate_month not in used_months or len(selected_points) == 0:
                    selected_points.append({
                        'name': point_name,
                        'index': target_idx + self.moving_average_window - 1,
                        'data': candidate_point,
                        'month': candidate_month
                    })
                    used_months.add(candidate_month)
                else:
                    # Search for alternative from different month
                    found_alternative = False
                    search_range = min(50, len(available_data) - 1)
                    search_offsets = []
                    
                    for offset in range(1, search_range + 1):
                        if target_idx + offset < len(available_data):
                            search_offsets.append(offset)
                        if target_idx - offset >= 0:
                            search_offsets.append(-offset)
                    
                    for offset in search_offsets:
                        alt_idx = target_idx + offset
                        if 0 <= alt_idx < len(available_data):
                            alt_candidate = available_data.iloc[alt_idx]
                            alt_month = alt_candidate['Month']
                            
                            if alt_month not in used_months:
                                selected_points.append({
                                    'name': point_name,
                                    'index': alt_idx + self.moving_average_window - 1,
                                    'data': alt_candidate,
                                    'month': alt_month
                                })
                                used_months.add(alt_month)
                                found_alternative = True
                                break
                    
                    if not found_alternative:
                        selected_points.append({
                            'name': f'{point_name}_SameMonth',
                            'index': target_idx + self.moving_average_window - 1,
                            'data': candidate_point,
                            'month': candidate_month
                        })
        
        # Convert to dictionary
        for point in selected_points:
            reference_points[point['name']] = {
                'datetime': point['data'][datetime_col],
                'moving_average': point['data']['Moving_Average'],
                'broadband': point['data']['Broadband'],
                'month': str(point['month']),
                'index': point['index'],
                'days_from_start': (point['data'][datetime_col] - data[datetime_col].iloc[0]).days
            }
        
        return reference_points
    
    def calculate_deviations(self, 
                            data: pd.DataFrame,
                            broadband_col: str = 'Broadband') -> pd.DataFrame:
        """
        Calculate deviations between broadband and moving average values.
        
        Parameters:
        -----------
        data : pd.DataFrame
            Input dataframe with 'Moving_Average' column
        broadband_col : str, default='Broadband'
            Name of the broadband column
            
        Returns:
        --------
        pd.DataFrame
            Dataframe with added 'Deviation' column
        """
        df = data.copy()
        df['Deviation'] = df[broadband_col] - df['Moving_Average']
        return df
    
    def calculate_iqr_bounds(self, data: pd.DataFrame) -> Dict[str, float]:
        """
        Calculate IQR-based bounds for anomaly detection.
        
        Parameters:
        -----------
        data : pd.DataFrame
            Input dataframe with 'Deviation' column
            
        Returns:
        --------
        Dict[str, float]
            Dictionary containing Q1, Q3, IQR, and upper_bound
        """
        deviation_values = data['Deviation'].dropna()
        
        Q1 = np.percentile(deviation_values, 25)
        Q3 = np.percentile(deviation_values, 75)
        IQR = Q3 - Q1
        upper_bound = Q3 + 4 * IQR
        
        return {
            'Q1': Q1,
            'Q3': Q3,
            'IQR': IQR,
            'upper_bound': upper_bound
        }
    
    def preprocess(self, 
                   data: pd.DataFrame,
                   datetime_col: str = 'Date/Time',
                   broadband_col: str = 'Broadband') -> Dict:
        """
        Complete preprocessing pipeline for vibration data.
        
        Parameters:
        -----------
        data : pd.DataFrame
            Input dataframe containing vibration data
        datetime_col : str, default='Date/Time'
            Name of the datetime column
        broadband_col : str, default='Broadband'
            Name of the broadband column
            
        Returns:
        --------
        Dict
            Dictionary containing:
            - processed_data: Cleaned and processed dataframe
            - removed_outliers: Dataframe of removed outlier points
            - outlier_threshold: Threshold value used for outlier removal
            - reference_points: Dictionary of reference points
            - iqr_bounds: Dictionary of IQR statistics
        """
        # Step 1: Load and validate
        validated_data = self.load_and_validate_data(data, datetime_col, broadband_col)
        
        # Step 2: Filter by threshold
        filtered_data = self.filter_by_threshold(validated_data, broadband_col)
        
        # Step 3: Remove outliers
        cleaned_data, removed_data, threshold = self.remove_outliers(filtered_data, broadband_col)
        
        # Step 4: Calculate moving average
        ma_data = self.calculate_moving_average(cleaned_data, broadband_col)
        
        # Step 5: Get reference points
        reference_points = self.get_reference_points(ma_data, datetime_col)
        
        # Step 6: Calculate deviations
        processed_data = self.calculate_deviations(ma_data, broadband_col)
        
        # Step 7: Calculate IQR bounds
        iqr_bounds = self.calculate_iqr_bounds(processed_data)
        
        return {
            'processed_data': processed_data,
            'removed_outliers': removed_data,
            'outlier_threshold': threshold,
            'reference_points': reference_points,
            'iqr_bounds': iqr_bounds,
            'config': {
                'moving_average_window': self.moving_average_window,
                'min_tve': self.min_tve,
                'outlier_std_threshold': self.outlier_std_threshold
            }
        }
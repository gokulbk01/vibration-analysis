"""
Vibration Analysis Library

A Python library for preprocessing and analyzing vibration data from rotating 
and reciprocating assets.
"""

__version__ = "0.1.0"
__author__ = "Gokul B"
__email__ = "gokulbk01@gmail.com"

from .preprocessor import VibrationPreprocessor

__all__ = ['VibrationPreprocessor']